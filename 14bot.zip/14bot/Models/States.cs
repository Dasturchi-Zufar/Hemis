namespace Models
{
    public enum LoginState
    {
        None,
        WaitingLogin,
        WaitingPassword
    }
}
